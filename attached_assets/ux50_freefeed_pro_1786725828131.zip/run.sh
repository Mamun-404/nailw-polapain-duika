#!/usr/bin/env bash
# UX50 FreeFeed premium signal bot - free Yahoo feed, no MT5/Wine needed
# Usage:
#   1. Edit TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID below (get token from @BotFather, free)
#   2. bash run.sh        -> start in background, log to bot.log
#   3. bash run.sh stop   -> stop the bot
#   4. tail -f bot.log    -> watch signals
set -e
cd "$(dirname "$0")"

export EXNESS_SYMBOLS="${EXNESS_SYMBOLS:-EURUSD,GBPUSD,USDJPY,AUDUSD,USDCAD,NZDUSD,USDCHF,EURGBP,EURJPY,GBPJPY,EURCHF,GBPCHF,EURAUD,EURNZD,EURCAD,GBPAUD,GBPNZD,GBPCAD,AUDJPY,AUDNZD,AUDCAD,AUDCHF,NZDJPY,NZDCAD,NZDCHF,CADJPY,CADCHF,CHFJPY,USDZAR,USDTRY,USDMXN,USDSGD,USDPLN,USDNOK,USDSEK,USDCNH,USDINR,XAUUSD,XAGUSD,XPTUSD,XPDUSD,USOIL,UKOIL,NGAS,US30,US500,NAS100,GER40,FR40,EU50,UK100,JPN225,HK50,AU200,ES35,BTCUSD,ETHUSD,XRPUSD,SOLUSD,DOGEUSD,LTCUSD,BCHUSD}"
export EXNESS_TIMEFRAME_MINUTES="15"
export EXNESS_SCAN_SECONDS="120"
export EXNESS_MIN_SIGNAL_CONFIDENCE="90"
export EXNESS_MIN_RR="1.30"
export EXNESS_MAX_SPREAD_POINTS="200"
export EXNESS_SIGNAL_COOLDOWN_SECONDS="900"
export EXNESS_STATUS_EVERY_SECONDS="1800"
export EXNESS_ADAPTIVE_LEVEL="3"
export EXNESS_DIVERSIFICATION="1"
export EXNESS_MAX_OPEN_SIGNALS="3"
export EXNESS_RISK_PERCENT="1.0"
export EXNESS_ACCOUNT_BALANCE="1000"
export EXNESS_SESSION_FILTER="1"
export EXNESS_PREMIUM_STATS_FILE="$PWD/premium_signal_stats.json"
export EXNESS_OPEN_SIGNALS_FILE="$PWD/premium_open_signals.json"
export EXNESS_MIN_STATS_SAMPLES="20"
export EXNESS_MIN_SYMBOL_WINRATE="48"
export EXNESS_MAX_CONSECUTIVE_LOSSES="3"
export EXNESS_OUTCOME_LOOKAHEAD="12"
export EXNESS_MAX_CANDLE_ATR="3.0"
export EXNESS_MIN_CANDLE_ATR="0.12"
export EXNESS_MIN_OOS_WINRATE="48"

# --- Telegram (free, from @BotFather) ---
export TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-7226048762:AAHLqhO3JLrmX2eXY4dFUXXpaTrGsim0ZJ8}"
export TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-5068753643}"

if [ "$1" = "stop" ]; then
    if [ -f bot.pid ]; then
        kill "$(cat bot.pid)" 2>/dev/null && echo "bot stopped"
        rm -f bot.pid
    fi
    pkill -f "[u]x50_freefeed.py" 2>/dev/null
    pkill -f "[w]atchdog" 2>/dev/null
    echo "bot stopped"
    exit 0
fi

if [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ]; then
    echo "WARNING: TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID empty - signals will be printed to log only."
    echo "Create free bot at @BotFather, then put token+chat id into run.sh"
fi

# Watchdog loop with pidfile: restart automatically if the bot dies
nohup bash -c '
    cd "$(dirname "$0")" 2>/dev/null || cd .
    while true; do
        if [ ! -f bot.pid ] || ! kill -0 "$(cat bot.pid 2>/dev/null)" 2>/dev/null; then
            echo "[watchdog] $(date "+%F %T") starting bot" >> bot.log
            python3 ux50_freefeed.py >> bot.log 2>&1 &
            echo $! > bot.pid
        fi
        sleep 10
    done
' >> bot.log 2>&1 &
echo "bot started (watchdog) pid=$! -> log: $PWD/bot.log"
