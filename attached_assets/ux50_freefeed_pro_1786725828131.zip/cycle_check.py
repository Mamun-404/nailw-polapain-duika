import asyncio
import os
import sys

os.environ["EXNESS_SESSION_FILTER"] = "0"
os.environ["EXNESS_PREMIUM_STATS_FILE"] = "/home/kali/ux50_freefeed/stats_live.json"
os.environ["EXNESS_OPEN_SIGNALS_FILE"] = "/home/kali/ux50_freefeed/open_live.json"
os.environ["LOG_LEVEL"] = "ERROR"
sys.path.insert(0, "/home/kali/ux50_freefeed")
import ux50_freefeed as bot

SAMPLE = ["EURUSD", "XAUUSD", "US30", "BTCUSD", "USOIL", "UK100"]


async def main():
    b = bot.FreeFeedBridge()
    print(await b.connect(), flush=True)
    for s in SAMPLE:
        res = await bot.run_signal_cycle(b, s, 15)
        print(f"{s:7s} -> {'SIGNAL ' + str(res['direction']) if res else 'no signal (gated)'}", flush=True)
        await asyncio.sleep(1)


asyncio.run(main())